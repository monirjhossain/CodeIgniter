<div>
    <h1>Successfully Insert</h1>
    <p><?php echo anchor('super_admin/addProject', 'Try it again!'); ?></p>
</div>
